import schedule
import time
from datetime import datetime
import kb_chachacha

def schedule_start():
    print("────────────────────────────")
    print("Server Working Start────────")
    kb_chachacha.start_kbchacha()

# schedule.every(1).hours.do(schedule_start)
schedule.every(30).minutes.do(schedule_start)

while True:
    schedule.run_pending()

    now = datetime.now()
    current_time = now.strftime('%Y-%m-%d %H:%M:%S')
    print("--server active : {}".format(current_time))
    time.sleep(1)